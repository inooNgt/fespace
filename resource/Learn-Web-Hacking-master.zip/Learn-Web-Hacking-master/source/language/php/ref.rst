参考链接
========================================

Bypass
----------------------------------------
- `php open basedir bypass <https://www.tarlogic.com/en/blog/how-to-bypass-disable_functions-and-open_basedir/>`_
- `open basedir bypass <https://www.tarlogic.com/en/blog/how-to-bypass-disable_functions-and-open_basedir/>`_
- `Bypass Disable functions Shell <https://github.com/l3m0n/Bypass_Disable_functions_Shell>`_

Tricks
----------------------------------------
- `php wrappers <https://www.ptsecurity.com/upload/corporate/ru-ru/webinars/ics/%D0%90.%D0%9C%D0%BE%D1%81%D0%BA%D0%B2%D0%B8%D0%BD_%D0%9E_%D0%B1%D0%B5%D0%B7%D0%BE%D0%BF_%D0%B8%D1%81%D0%BF_%D0%A0%D0%9D%D0%A0_wrappers.pdf>`_
- `反序列化之PHP原生类的利用 <http://www.cnblogs.com/iamstudy/articles/unserialize_in_php_inner_class.html>`_
- `php解密的数种方法 <https://www.leavesongs.com/PENETRATION/unobfuscated-phpjiami.html>`_

WebShell
----------------------------------------
- `PHP htaccess inject <https://github.com/sektioneins/pcc/wiki/PHP-htaccess-injection-cheat-sheet>`_
- `php木马加密 <https://blog.manchestergreyhats.co.uk/2018/11/07/php-malware-examination/>`_
- `PHP WebShell变形技术总结  <https://www.freebuf.com/articles/web/155891.html>`_
- `一些不包含数字和字母的webshell <https://www.leavesongs.com/PENETRATION/webshell-without-alphanum.html>`_

Phar
----------------------------------------
- `US Black Hat 2018 Phar <https://i.blackhat.com/us-18/Thu-August-9/us-18-Thomas-Its-A-PHP-Unserialization-Vulnerability-Jim-But-Not-As-We-Know-It-wp.pdf>`_
- `利用 phar 拓展 php 反序列化漏洞攻击面 <https://paper.seebug.org/680/>`_
- `Phar与Stream Wrapper造成PHP RCE的深入挖掘 <https://blog.zsxsoft.com/post/38>`_

运行
----------------------------------------
- `Learning the PHP lifecycle <http://www.phpinternalsbook.com/php7/extensions_design/php_lifecycle.html>`_
- `PHP7内核剖析 <https://github.com/pangudashu/php7-internal>`_
