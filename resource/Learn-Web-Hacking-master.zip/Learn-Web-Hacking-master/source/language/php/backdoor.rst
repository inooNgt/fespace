后门
================================

php.ini构成的后门
---------------------------------
利用 auto_prepend_file 和 include_path

.user.ini文件构成的PHP后门
---------------------------------
.user.ini可运行于所有以fastcgi运行的server。
利用方式同php.ini
