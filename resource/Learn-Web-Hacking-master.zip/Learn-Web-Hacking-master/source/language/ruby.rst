Ruby
========================================

参考链接
----------------------------------------
- `ruby deserialization <https://www.elttam.com.au/blog/ruby-deserialization/>`_
