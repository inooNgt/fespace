ASP
========================================

简介
----------------------------------------
ASP是动态服务器页面(Active Server Page)，是微软开发的类似CGI脚本程序的一种应用，其网页文件的格式是 ``.asp`` 。

参考链接
----------------------------------------
- `Deformity ASP/ASPX Webshell、Webshell Hidden Learning <https://www.cnblogs.com/LittleHann/p/5016999.html>`_
