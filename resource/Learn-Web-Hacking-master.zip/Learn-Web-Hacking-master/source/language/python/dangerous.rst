危险函数 / 模块列表
================================

命令执行
--------------------------------
- os.popen
- os.system
- os.spawn
- os.fork
- os.exec
- popen2
- commands
- subprocess
- exec
- execfile
- eval
- timeit.sys
- timeit.timeit
- platform.os
- platform.sys
- platform.popen
- pty.spawn
- pty.os
- bdb.os
- cgi.sys
- ...

危险第三方库
--------------------------------
- Template
- subprocess32 

反序列化
--------------------------------
- marshal
- PyYAML
- pickle
- cPickle
- shelve
- PIL
