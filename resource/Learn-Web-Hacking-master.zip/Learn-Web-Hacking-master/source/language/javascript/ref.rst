参考链接
========================================
- `JavaScript反调试技巧 <http://www.freebuf.com/articles/system/163579.html>`_
- `ECMAScript Language Specification <http://www.ecma-international.org/ecma-262/5.1/#sec-15.3.4.5>`_
- `js prototype <https://www.zhihu.com/question/34183746?sort=created>`_
- `javascript防劫持 <https://github.com/scscms/guardJs/>`_
- `XSS 前端防火墙 <http://fex.baidu.com/blog/2014/06/xss-frontend-firewall-3.html>`_
- `exploiting node js deserialization bug for remote code execution <https://opsecx.com/index.php/2017/02/08/exploiting-node-js-deserialization-bug-for-remote-code-execution/>`_
