持久化
----------------------------------------

Windows
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
- `WinPwnage <https://github.com/rootm0s/WinPwnage>`_

WebShell连接工具
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
- `菜刀 <https://github.com/Chora10/Cknife>`_
- `antSword <https://github.com/antoor/antSword>`_

WebShell
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
- `webshell <https://github.com/tennc/webshell>`_
- `PHP backdoors <https://github.com/bartblaze/PHP-backdoors>`_
- `weevely3 <https://github.com/epinna/weevely3>`_
- `php bash - semi-interactive web shell <https://github.com/Arrexel/phpbash>`_
- `Python RSA Encrypted Shell <https://github.com/Eitenne/TopHat.git>`_
- `b374k - PHP WebShell Custom Tool <https://github.com/b374k/b374k>`_

后门
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
- `pwnginx <https://github.com/t57root/pwnginx>`_
- `Apache backdoor <https://github.com/WangYihang/Apache-HTTP-Server-Module-Backdoor>`_
- `SharpGen <https://github.com/cobbr/SharpGen>`_  .NET Core console application that utilizes the Rosyln C# compiler to quickly cross-compile .NET Framework console applications or libraries

密码提取
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
- `mimikatz <https://github.com/gentilkiwi/mimikatz>`_
- `sshLooter <https://github.com/mthbernardes/sshLooter>`_
- `keychaindump <https://github.com/juuso/keychaindump>`_

提权
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
- `linux exploit suggester <https://github.com/mzet-/linux-exploit-suggester>`_
- `LinEnum <https://github.com/rebootuser/LinEnum>`_ Scripted Local Linux Enumeration & Privilege Escalation Checks
- `AutoLocalPrivilegeEscalation <https://github.com/ngalongc/AutoLocalPrivilegeEscalation>`_
- `WindowsExploits <https://github.com/abatchy17/WindowsExploits>`_
- `BeRoot <https://github.com/AlessandroZ/BeRoot>`_ Privilege Escalation Project - Windows / Linux / Mac
- `GTFOBins <https://github.com/GTFOBins/GTFOBins.github.io>`_ Curated list of Unix binaries that can be exploited to bypass system security restrictions

RAT
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
- `QuasarRAT <https://github.com/quasar/QuasarRAT>`_

C2
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
- `cobalt strike <https://www.cobaltstrike.com>`_
- `Empire <https://github.com/EmpireProject/Empire>`_
- `pupy <https://github.com/n1nj4sec/pupy>`_

日志清除
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
- `Log killer <https://github.com/Rizer0/Log-killer>`_
