Fuzz
----------------------------------------

Web Fuzz
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
- `wfuzz <https://github.com/xmendez/wfuzz>`_
- `SecLists <https://github.com/danielmiessler/SecLists>`_
- `fuzzdb <https://github.com/fuzzdb-project/fuzzdb>`_
- `foospidy payloads <https://github.com/foospidy/payloads>`_

Unicode Fuzz
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
- `utf16encode <http://www.fileformat.info/info/charset/UTF-16/list.htm>`_

WAF Bypass
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
- `abuse ssl bypass waf <https://github.com/LandGrey/abuse-ssl-bypass-waf>`_
- `wafninja <https://github.com/khalilbijjou/wafninja>`_
