XSS数据源
========================================

URL
----------------------------------------
- ``location``
- ``location.href``
- ``location.pathname``
- ``location.search``
- ``location.hash``
- ``document.URL``
- ``document.documentURI``
- ``document.baseURI``

Navigation
----------------------------------------
- ``window.name``
- ``document.referrer``

Communication
----------------------------------------
- ``Ajax``
- ``Fetch``
- ``WebSocket``
- ``PostMessage``

Storage
----------------------------------------
- ``Cookie``
- ``LocalStorage``
- ``SessionStorage``
