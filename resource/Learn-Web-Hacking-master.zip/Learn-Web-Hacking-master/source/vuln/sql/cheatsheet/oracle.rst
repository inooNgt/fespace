Oracle Payload
=====================================

- dump
    - ``SELECT * FROM ALL_TABLES``

