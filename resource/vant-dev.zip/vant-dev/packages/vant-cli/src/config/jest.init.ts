import Vue from 'vue';
import 'jest-canvas-mock';
// @ts-ignore
import Package from '../../dist/package-entry';

Vue.use(Package);
