# Eslint Config of Vant

## Install

#### NPM

```shell
npm i @vant/eslint-config -D
```

#### YARN

```shell
yarn add @vant/eslint-config --dev
```

## Usage

```js
{
  "extends": ["@vant"]
}
```
