var axios = require('axios');

axios.defaults.baseURL = 'https://www.easy-mock.com/mock/5a791f0df6b5690e010750a3/api';

module.exports = axios;