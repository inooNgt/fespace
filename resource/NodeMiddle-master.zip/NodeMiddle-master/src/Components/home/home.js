import './home.scss';
$(function () {
	
})