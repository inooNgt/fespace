import "./base.scss";

$(function(){
	console.debug('Hello! 欢迎关注 Keyon Y (xilan.me) 的博客~');
});