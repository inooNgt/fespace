import "./index.scss"

$(function(){

});