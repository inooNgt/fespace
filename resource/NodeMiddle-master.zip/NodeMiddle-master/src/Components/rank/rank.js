import './rank.scss';
$(function () {
	
})